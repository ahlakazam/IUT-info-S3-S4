#!/bin/sh

#Timezone US=>FR
unlink /etc/localtime
ln -s /usr/share/zoneinfo/Europe/Paris /etc/localtime

export DEBIAN_FRONTEND=noninteractive

#Local FR repos
sed -i s/us.arch/fr.arch/g /etc/apt/sources.list

aptitude update

aptitude install -y manpages manpages-posix-dev manpages-posix manpages-dev emacs24-nox bc tree build-essential git tig
