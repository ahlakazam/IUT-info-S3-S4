#include <windows.h>
 
int WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPWSTR lpCmdLine, int nCmdShow )
{
    MessageBox( NULL, TEXT ("Hello world!\n"), TEXT (""), MB_OK );
    return 0;
}
