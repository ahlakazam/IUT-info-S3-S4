#include <stdio.h>
#include <stdlib.h>
 
/* C99 : le prototype de main est normalis� */
int main (int argc, char * argv[])
{
	printf ( "Hello world!" ) ;
	/* La valeur de sortie en cas de succ�s est
	   normalis�e et d�pend de l'impl�mentation
	 */
 
	return EXIT_SUCCESS ;
 
}
